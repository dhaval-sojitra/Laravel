<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">

    <title>Document</title>
</head>
<body>
    <h1>My Blog</h1>
<nav class="navbar navbar-expand-lg bg-body-tertiary">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Navbar</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="#">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Features</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Pricing</a>
        </li>
        <li class="nav-item">
          <a class="nav-link disabled" aria-disabled="true">Disabled</a>
        </li>
      </ul>
    </div>
  </div>
</nav>
<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quidem quibusdam laborum quasi ducimus dicta neque molestiae officia suscipit nesciunt atque, veniam minima. Voluptatibus at maxime esse dolorum cupiditate deleniti iure.
Iure doloribus esse odit ex sit, beatae optio, dolor, quos laboriosam cumque voluptate. Temporibus, quod provident ratione quaerat necessitatibus vero molestias error deleniti placeat architecto consequatur adipisci dolore repudiandae ut.
Eveniet et facere autem beatae quam placeat, deleniti tempora mollitia eius? Nisi provident aut veniam expedita dolorum quas hic dolor culpa, architecto eveniet aspernatur explicabo cupiditate corrupti porro, amet quibusdam!
Ipsam qui quibusdam culpa omnis fuga, neque ea totam? Molestias neque, iste tempora eveniet consequatur eos repellat id autem accusantium, odit qui ad? Voluptatibus illum porro aliquam cupiditate, architecto cumque.
Adipisci delectus dignissimos cumque fugiat odit eveniet aliquam! Impedit quo, ex obcaecati perferendis nesciunt officia et laborum provident animi, amet autem cumque sapiente! Animi exercitationem sit dolores sed doloremque assumenda?
Accusantium magnam recusandae aspernatur vitae? Alias delectus omnis eos debitis vitae exercitationem, cupiditate culpa quod aperiam ducimus at, nisi atque dolorem molestiae hic numquam est deleniti similique quisquam maiores et?
Reprehenderit doloremque, rerum laborum eos sapiente ratione? Corporis expedita esse, quo nemo iusto modi molestiae omnis fugit quia ratione maiores non quasi rem voluptatibus consequatur commodi unde voluptatem dolores necessitatibus.
Quam, illum! Vero autem itaque at sunt? Iste nam rerum harum a labore sit earum consectetur perspiciatis molestiae quis. Laborum facere, inventore itaque velit architecto incidunt repellendus nam quo aliquam!
Eligendi dolorum quis blanditiis perferendis tempora, nesciunt unde dolorem labore earum totam, quod nostrum ipsa repudiandae quos odit suscipit perspiciatis nobis aspernatur, doloremque deserunt adipisci minima aliquid? Similique, eius dicta.
Est quas numquam fugit vel necessitatibus fuga dolore quam facilis pariatur laudantium blanditiis dignissimos in, asperiores modi totam non id iusto nobis assumenda. Perferendis quasi sed odit quos iusto ipsam.
Possimus dolores officiis delectus, quaerat assumenda nisi itaque quibusdam minima quas tempore porro voluptatum aliquam, impedit aut eos excepturi illo. Est aliquam ut, harum id quod dolorem nulla debitis voluptates?
Eveniet totam numquam repellat laudantium sed qui commodi necessitatibus alias assumenda, distinctio consequuntur doloribus porro cupiditate nihil, quia odio minima beatae explicabo hic tempore autem! Iure vero necessitatibus voluptas corrupti?
Sapiente repellat tempore incidunt minus doloremque molestiae mollitia dolores nisi quas nihil culpa cupiditate voluptates a aliquid velit sit ex voluptatum vel, facere rerum pariatur iste architecto! Quis, iusto eligendi?
Labore optio mollitia minus quae! Voluptas excepturi cupiditate quod atque, a incidunt soluta sed corrupti nesciunt mollitia ad ut debitis reprehenderit labore harum laboriosam? Explicabo quaerat est saepe recusandae repellendus.
Magni rerum minus numquam cumque sit delectus fugiat, neque doloribus nostrum repellendus laborum! Optio nulla in vero itaque cumque quos, quidem exercitationem facilis dolore neque minima doloribus ea quasi nostrum!
Cupiditate, officia. Aliquam adipisci, officiis maxime facere neque consequatur quo doloremque inventore minus eum asperiores voluptatum quasi natus, assumenda sequi corrupti repudiandae molestiae perferendis impedit ab mollitia deserunt ratione quis?
Nostrum enim recusandae cupiditate soluta dolores quaerat, et maxime obcaecati voluptas ea numquam magnam itaque blanditiis dolor eligendi voluptate repudiandae libero odit in repellat, provident iste! Libero at maiores obcaecati?
Doloremque veniam molestias delectus omnis nisi totam voluptates aperiam quos? Quam at ipsam id ab iste, eaque veritatis, eius similique repellendus laboriosam libero dicta fugit nostrum dolor accusantium, perspiciatis odio.
Fugit, numquam, rerum tenetur neque obcaecati praesentium nulla doloribus, ducimus culpa fuga reiciendis error deleniti magnam! Ea aut eos iste reprehenderit, placeat eius provident, similique veniam cumque, itaque vel delectus.
Magnam, eum voluptatem perferendis iste soluta facere laborum? Placeat debitis facere nobis vitae earum minus. Sint autem, officia, nulla dolore officiis fuga consectetur libero facilis consequuntur cum nesciunt provident mollitia!</p>
<hr>
<p>Copyright Information My Blog</p>
</body>
</html>
