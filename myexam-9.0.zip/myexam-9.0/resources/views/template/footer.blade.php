<div>
    <p style="text-align: center; background-color: #bed4da; color: black; margin-top: 50px;">All Rights Reserved &copyDhaval Sojitra 2024</p>
</div>