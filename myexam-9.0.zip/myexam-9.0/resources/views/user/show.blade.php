@extends('template.sample-layout')
@section('content')

<h2>Name : </h2>
<h3>{{$data->name}}</h3>

@endsection