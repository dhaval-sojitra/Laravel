<div>
    <p style="text-align: center; background-color: #bed4da; color: black; margin-top: 50px;">All Rights Reserved &copyDhaval Sojitra 2024</p>
</div><?php /**PATH D:\MCA\Sem 2\Github\Laravel\myexam-9.0\resources\views/template/footer.blade.php ENDPATH**/ ?>