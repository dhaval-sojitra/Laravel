
<?php $__env->startSection('content'); ?>
    <h2 align="center">Add Data</h2>
    <div class="container">

        <form method="POST" action="<?php echo e(route('Mypro.store')); ?>">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="exampleInputEmail1">Name</label>
                <input type="text" name="name" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"
                    placeholder="Enter your name">
            </div>
            <div class="form-group">
                <label for="exampleInputPassword1">City</label>
                <input type="text" name="city" class="form-control" id="exampleInputPassword1"
                    placeholder="Enter Your city">
            </div>
            <div class="form-group">
                <label for="exampleInputPassword1">Phone</label>
                <input type="number" name="phone" class="form-control" id="exampleInputPassword1"
                    placeholder="Enter Your Phone Number">
            </div>
            <label for="exampleInputPassword1">Address</label>
            <textarea class="form-control" id="editor" name="address" rows="3"></textarea>

            <script>
                ClassicEditor
                    .create(document.querySelector('#editor'))
                    .catch(error => {
                        console.error(error);
                    });
            </script>
            <div style="display: flex; justify-content: center; margin-top: 10px;">

                <button type="submit" class="btn btn-primary">Submit</button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.sample-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\MCA\Sem 2\Github\Laravel\myexam-9.0\resources\views/user/create.blade.php ENDPATH**/ ?>