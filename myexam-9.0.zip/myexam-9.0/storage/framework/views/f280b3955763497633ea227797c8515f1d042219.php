
<?php $__env->startSection('content'); ?>

<h2>Name : </h2>
<h3><?php echo e($data->name); ?></h3>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.sample-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\MCA\Sem 2\Github\Laravel\myexam-9.0\resources\views/user/show.blade.php ENDPATH**/ ?>